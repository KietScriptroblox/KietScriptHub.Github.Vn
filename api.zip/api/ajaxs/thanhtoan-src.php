<?php
include('ini.php');

$id = $_POST['id'];
$query = $connect->query("SELECT * FROM `SourceCode` WHERE `id` = '$id'")->fetch_array();

$tienphaitra = $query['price'] ;

if(empty($id) || $id != $query['id']){
    echo json_api('Mã nguồn không hợp lệ!','error');
} else if($getUser['monney'] < $tienphaitra){
    echo json_api('Số dư không đủ để thanh toán!','error');
} else {
    
    $inTrue = $connect->query("INSERT INTO `DanhSachCode`(`id`, `username`, `name`, `theme`, `time`, `price`) VALUES (NULL,'".$getUser['username']."','".$query['name']."','$id','".time()."','$tienphaitra')");
    if($inTrue){
        $connect->query("UPDATE Users SET `monney` = `monney` - $tienphaitra, `re_monney` = `re_monney` + $tienphaitra WHERE username = '".$getUser['username']."'");
        echo json_api('Mua mã nguồn thành công!','success');
    } else {
        echo json_api('Không thể mua mã nguồn!','error');
    }
}

?>