<?php
include('ini.php');

$id = $_POST['id'];
$name = $_POST['name'];
$query = $connect->query("SELECT * FROM `MauLogo` WHERE `id` = '$id'")->fetch_array();

$tienphaitra = $query['price'];

$discounts = $_POST['discount'];
$queryDiscounts = $connect->query("SELECT * FROM MaGiamGia WHERE code = '$discounts' AND service = 'design'")->fetch_array();
$limitDiscounts = $connect->query("SELECT * FROM MaGiamGia WHERE code = '$discounts' AND luotdung <= '".$queryDiscounts['gioihan']."' AND service = 'design'")->num_rows;

if($discounts != '' && $discounts == $queryDiscounts['code'] && $queryDiscounts['luotdung'] <= $queryDiscounts['gioihan']){
    if($queryDiscounts['loai'] == 'phantram'){
        $tienphaitra = checkGia($tienphaitra, $queryDiscounts['giamgia']);
    } else if($queryDiscounts['loai'] == 'tien'){
        $tienphaitra = $tienphaitra - $queryDiscounts['giamgia'];
    }
   $statusDiscount = 'true';
}


if(empty($id) || $id != $query['id']){
    echo json_api('Bản thiết kế không hợp lệ!','error');
} else if(empty($name)){
    echo json_api('Vui lòng nhập chữ cho bản thiết kế!', 'error');
} else if(!empty($discounts) && $limitDiscounts < 1){
    echo json_api('Mã Giảm Giá Không Hợp Lệ', 'error');
} else if($getUser['monney'] < $tienphaitra){
    echo json_api('Số dư không đủ để thanh toán!','error');
} else {
    
    $inTrue = $connect->query("INSERT INTO `DanhSachLogo`(`id`, `username`, `name`, `theme`, `status`, `time`, `logo_output`) VALUES (NULL,'".$getUser['username']."','$name','$id','0','".time()."','Đang Thiết Kế')");
    if($inTrue){
        
        if($statusDiscount == 'true'){
            $connect->query("UPDATE MaGiamGia SET luotdung = luotdung + '1' WHERE code = '$discounts'");
        }
        
        $connect->query("UPDATE Users SET `monney` = `monney` - $tienphaitra, `re_monney` = `re_monney` + $tienphaitra WHERE username = '".$getUser['username']."'");
        echo json_api('Thanh toán thành công, đang xử lí!','success');
    } else {
        echo json_api('Không thể tạo trang web, hãy thử lại sau!','error');
    }
}

?>