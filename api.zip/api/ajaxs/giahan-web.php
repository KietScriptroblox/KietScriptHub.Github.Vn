<?php
include('ini.php');

$id = $_POST['id'];
$hsd = $_POST['hsd'];
$query = $connect->query("SELECT * FROM DanhSachWeb WHERE id = '$id'")->fetch_array();
$product = $connect->query("SELECT * FROM Products WHERE id = '".$query['theme']."'")->fetch_array();
$tienphaitra = $product['price'] * $hsd;
$timenew = $query['orvertime'] + 2592000 * $hsd;

if($id != $query['id']){
    echo json_api('Đơn Hàng Không Hợp Lệ','error');
} else if($hsd < 1) {
    echo json_api('Hạn Sử Dụng Không Hợp Lệ','error');
} else if($getUser['monney'] < $tienphaitra) {
    echo json_api('Không Đủ Số Dư Để Thanh Toán','error');
} else {
    $inTrue = $connect->query("UPDATE DanhSachWeb SET orvertime = '$timenew' WHERE id = '$id'");
    if($inTrue){
         $connect->query("UPDATE Users SET `monney` = `monney` - $tienphaitra, `re_monney` = `re_monney` + $tienphaitra WHERE username = '".$getUser['username']."'");
        echo json_api('Gia Hạn Thành Công '.$hsd.' Tháng','success');
    } else {
        echo json_api('Không Thể Xử Lí','error');
    }
}

?>