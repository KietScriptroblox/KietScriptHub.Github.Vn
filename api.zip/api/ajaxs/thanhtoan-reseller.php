<?php
include('ini.php');

    $id = $_POST['id'];
    $domain = $_POST['domain'];
    $email = $_POST['email'];
    $hsd = $_POST['hsd'];
    
    $query = json_decode(file_get_contents("$hostapi/Api/api.php?type=getpackage_reseller&id=$id"), true);
    $tienphaitra = $query['price'] * $_POST['hsd'];
    $orvertime = time()+(2592000 * $_POST['hsd']);
    
    $checkLimit = $connect->query("SELECT * FROM `DanhSachReseller` WHERE `domain` = '$domain' AND `server` = '".$query['uname']."'")->num_rows;
    $tienphaitra = $query['price'] * $hsd;
    
    $discounts = $_POST['discount'];
    $queryDiscounts = $connect->query("SELECT * FROM MaGiamGia WHERE code = '$discounts' AND service = 'whm'")->fetch_array();
    $limitDiscounts = $connect->query("SELECT * FROM MaGiamGia WHERE code = '$discounts' AND luotdung <= '".$queryDiscounts['gioihan']."' AND service = 'whm'")->num_rows;
    
    if($discounts != '' && $discounts == $queryDiscounts['code'] && $queryDiscounts['luotdung'] <= $queryDiscounts['gioihan']){
        if($queryDiscounts['loai'] == 'phantram'){
            $tienphaitra = checkGia($tienphaitra, $queryDiscounts['giamgia']);
        } else if($queryDiscounts['loai'] == 'tien'){
            $tienphaitra = $tienphaitra - $queryDiscounts['giamgia'];
        }
       $statusDiscount = 'true';
    }


    if(empty($id) || $id != $query['id']){
        echo json_encode(['message' => 'ID Dịch Vụ Không Hợp Lệ!', 'status' => 'error']);
    } else if(empty($domain)){
        echo json_encode(['message' => 'Vui Lòng Nhập Tên Miền', 'status' => 'error']);
    } else if(empty($hsd) || $hsd < 1){
        echo json_encode(['message' => 'Hạn Sử Dụng Không Hợp Lệ!', 'status' => 'error']);
    } else if($checkLimit == 1){
        echo json_encode(['message' => 'Tên Miền Đã Tồn Tại Trên Máy Chủ Này!', 'status' => 'error']);
    } else if(!empty($discounts) && $limitDiscounts < 1){
        echo json_api('Mã Giảm Giá Không Hợp Lệ', 'error');
    } else if($getUser['monney'] < $tienphaitra) {
        echo json_encode(['message' => 'Số Dư Không Đủ Để Thanh Toán!', 'status' => 'error']);
    } else {
        
        $curl = curl_init();
        curl_setopt($curl, CURLOPT_URL, "$hostapi/Api/api.php?type=thanhtoan_reseller&domain=$domain&email=$email&hsd=$hsd&id=$id&apikey=$apikey");
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        $response_data = curl_exec($curl);
        
        if (curl_errno($curl)) {
            echo json_encode(['message' => 'cURL Error: ' . curl_error($curl), 'status' => 'error']);
        } else {
            $response = json_decode($response_data, true);
        
            if ($response['status'] == 'error') {
                echo json_encode(['message' => $response['message'], 'status' => 'error']);
            } else if ($response['status'] == 'success') {
                $inTrue = $connect->query("INSERT INTO `DanhSachReseller`(`id`, `username`, `domain`, `email`, `package`, `server`) VALUES (NULL,'".$getUser['username']."','$domain','$email','".$query['package']."','".$query['server']."')");
                if ($inTrue) {
                    if($statusDiscount == 'true'){
                        $connect->query("UPDATE MaGiamGia SET luotdung = luotdung + '1' WHERE code = '$discounts'");
                    }
                    $connect->query("UPDATE Users SET `monney` = `monney` - $tienphaitra, `re_monney` = `re_monney` + $tienphaitra WHERE username = '".$getUser['username']."'");
                    echo json_encode(['message' => $response['message'], 'status' => 'success']);
                } else {
                    echo json_encode(['message' => 'Không thể lưu dữ liệu!'.$connect->error, 'status' => 'error']);
                }
            }
        }
        
        curl_close($curl);

}
?>