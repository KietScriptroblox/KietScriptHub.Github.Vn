<?php
include('ini.php');

$id = $_POST['id'];
$domain = $_POST['domain'];
$hsd = $_POST['hsd'];
$taikhoan = $_POST['taikhoan'];
$matkhau = $_POST['matkhau'];

$query = $connect->query("SELECT * FROM `Products` WHERE `id` = '$id'")->fetch_array();
$limitDomain = $connect->query("SELECT * FROM `DanhSachWeb` WHERE `domain` = '$domain' AND `status` IN (0,1)")->num_row;
$tienphaitra = $query['price'] * $hsd;
$orvertime = time() + (2592000 * $hsd);

$discounts = $_POST['discount'];
$queryDiscounts = $connect->query("SELECT * FROM MaGiamGia WHERE code = '$discounts' AND service = 'shop'")->fetch_array();
$limitDiscounts = $connect->query("SELECT * FROM MaGiamGia WHERE code = '$discounts' AND luotdung <= '".$queryDiscounts['gioihan']."' AND service = 'shop'")->num_rows;

if($discounts != '' && $discounts == $queryDiscounts['code'] && $queryDiscounts['luotdung'] <= $queryDiscounts['gioihan']){
    if($queryDiscounts['loai'] == 'phantram'){
        $tienphaitra = checkGia($tienphaitra, $queryDiscounts['giamgia']);
    } else if($queryDiscounts['loai'] == 'tien'){
        $tienphaitra = $tienphaitra - $queryDiscounts['giamgia'];
    }
   $statusDiscount = 'true';
}

if(empty($id) || $id != $query['id']){
    echo json_api('Giao diện không hợp lệ!','error');
} else if(empty($domain)){
    echo json_api('Vui lòng nhập tên miền', 'error');
} else if(empty($hsd) || $hsd < 1){
    echo json_api('Hạn dùng đã chọn không hợp lệ!','error');
} else if(empty($taikhoan || $matkhau)){
    echo json_api('Vui lòng nhập thông tin quản trị cho web!','error');
} else if($limitDomain == 1){
    echo json_api('Tên miền đã được sử dụng','error');
} else if(!empty($discounts) && $limitDiscounts < 1){
    echo json_api('Mã Giảm Giá Không Hợp Lệ', 'error');
} else if($getUser['monney'] < $tienphaitra){
    echo json_api('Số dư không đủ để thanh toán!','error');
} else {
    
    $inTrue = $connect->query("INSERT INTO `DanhSachWeb`(`id`, `username`, `domain`, `taikhoan`, `matkhau`, `status`, `theme`, `time`, `orvertime`, `ghichu`, `timesuspended`) VALUES (NULL,'".$getUser['username']."','$domain','$taikhoan','$matkhau','0','$id','".time()."','$orvertime','NULL','0')");
    if($inTrue){
        $connect->query("UPDATE Users SET `monney` = `monney` - $tienphaitra, `re_monney` = `re_monney` + $tienphaitra WHERE username = '".$getUser['username']."'");
        if($statusDiscount == 'true'){
            $connect->query("UPDATE MaGiamGia SET luotdung = luotdung + '1' WHERE code = '$discounts'");
        }
        echo json_api('Tạo trang web thành công, đơn hàng đang được xử lí!','success');
    } else {
        echo json_api('Không thể tạo trang web, hãy thử lại sau!','error');
    }
}

?>